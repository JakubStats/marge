# marge
MARGE - Multivariate adaptive regression splines using generalized estimating equations

An R-package for:

Stoklosa, J. and Warton, D.I. (2018). A generalized estimating equation approach to multivariate adaptive regression splines. *Journal of Computational and Graphical Statistics* *27*, pp. 245-253.
